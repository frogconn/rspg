<?php

echo "hello world"
?>